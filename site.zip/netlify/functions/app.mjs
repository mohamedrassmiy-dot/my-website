import { getStore, getDeployStore } from '@netlify/blobs';
import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

const DEFAULT_SETTINGS = {
  site_name: 'Rassmiy Marketing',
  site_url: '',
  default_meta_description: 'Rassmiy Marketing — Digital Marketing, SEO, Paid Media, E-Commerce and Content.',
  site_keywords: 'digital marketing, SEO, performance marketing, ecommerce, content marketing',
  contact_email: 'mohamed.rassmiy@gmail.com',
  location: 'Riyadh, Saudi Arabia',
  favicon_path: '/assets/logo.jpg',
  default_og_image: '/assets/logo.jpg',
  global_schema: '',
  global_head_code: '',
  ga4_id: '',
  gtm_id: '',
  robots_txt: 'User-agent: *\nAllow: /\nDisallow: /admin/\n\nSitemap: /sitemap.xml\n'
};

function storeForContext() {
  const production = Netlify?.context?.deploy?.context === 'production';
  return production
    ? getStore('rassmiy-cms', { consistency: 'strong' })
    : getDeployStore('rassmiy-cms', { consistency: 'strong' });
}

async function loadState() {
  const store = storeForContext();
  const state = await store.get('state', { type: 'json' });
  if (state) {
    state.settings = { ...DEFAULT_SETTINGS, ...(state.settings || {}) };
    state.users ||= [];
    state.sessions ||= {};
    state.pages ||= [];
    state.articles ||= [];
    state.leads ||= [];
    state.loginAttempts ||= [];
    state.counters ||= { page: 0, article: 0, lead: 0, user: 0 };
    return state;
  }
  return {
    settings: { ...DEFAULT_SETTINGS },
    users: [], sessions: {}, pages: [], articles: [], leads: [], loginAttempts: [],
    counters: { page: 0, article: 0, lead: 0, user: 0 }
  };
}

async function saveState(state) {
  await storeForContext().setJSON('state', state);
}

function esc(v='') { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
function attr(v='') { return esc(v); }
function nowIso() { return new Date().toISOString(); }
function unixNow() { return Math.floor(Date.now()/1000); }
function slugify(v='') { return String(v).trim().toLowerCase().replace(/\s+/gu,'-').replace(/[^\p{L}\p{N}_-]+/gu,'').replace(/-+/g,'-').replace(/^-|-$/g,''); }
function hashPassword(password) { const salt=randomBytes(16); const hash=scryptSync(password,salt,64); return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`; }
function verifyPassword(password,encoded) { try { const [scheme,saltHex,hashHex]=String(encoded).split('$'); if(scheme!=='scrypt') return false; const expected=Buffer.from(hashHex,'hex'); const actual=scryptSync(password,Buffer.from(saltHex,'hex'),expected.length); return expected.length===actual.length && timingSafeEqual(expected,actual); } catch { return false; } }
function parseCookies(req) { const out={}; for(const part of String(req.headers.get('cookie')||'').split(';')){ const i=part.indexOf('='); if(i>0) out[part.slice(0,i).trim()]=decodeURIComponent(part.slice(i+1).trim()); } return out; }
function secureCookie(req) { return new URL(req.url).protocol === 'https:' ? '; Secure' : ''; }
function cookie(name,value,req,maxAge=60*60*24*7){ return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secureCookie(req)}`; }
function redirect(url,status=303,headers={}) { return new Response(null,{status,headers:{Location:url,...headers}}); }
function html(body,status=200,headers={}) { return new Response(body,{status,headers:{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff',...headers}}); }
function text(body,status=200,type='text/plain; charset=utf-8',headers={}) { return new Response(body,{status,headers:{'Content-Type':type,'X-Content-Type-Options':'nosniff',...headers}}); }
function siteBase(req,state) { const configured=String(state.settings.site_url||'').replace(/\/$/,''); return configured || new URL(req.url).origin; }
function jsonSafe(v=''){ if(!String(v).trim()) return ''; try{ JSON.parse(v); return v; }catch{return '';} }
function formToObject(fd){ const o={}; for(const [k,v] of fd.entries()) o[k]=String(v); return o; }
function checked(v){ return v ? 'checked' : ''; }
function selected(a,b){ return String(a)===String(b) ? 'selected' : ''; }
function flashUrl(path,msg,type='success'){ const u=new URL(path,'https://x.local'); u.searchParams.set('msg',msg); u.searchParams.set('type',type); return u.pathname+u.search; }
function flashHtml(url){ const msg=url.searchParams.get('msg'); if(!msg) return ''; return `<div class="flash ${url.searchParams.get('type')==='error'?'error':'success'}">${esc(msg)}</div>`; }
function csrfInput(session){ return `<input type="hidden" name="csrf" value="${attr(session.csrf)}">`; }
function isAdmin(session){ return Boolean(session?.userId); }
function cleanSessions(state){ const now=unixNow(); for(const [sid,s] of Object.entries(state.sessions||{})){ if(!s || Number(s.expiresAt||0)<=now) delete state.sessions[sid]; } }
function newSession(state,userId=null){ const sid=randomBytes(32).toString('hex'); const s={sid,userId,csrf:randomBytes(32).toString('hex'),expiresAt:unixNow()+60*60*24*7}; state.sessions[sid]=s; return s; }
function getOrCreateSession(req,state){ cleanSessions(state); const sid=parseCookies(req).rassmiy_sid; let s=sid?state.sessions[sid]:null; if(!s) s=newSession(state,null); else s.expiresAt=unixNow()+60*60*24*7; return s; }
function rotateSession(state,session,userId){ if(session?.sid) delete state.sessions[session.sid]; return newSession(state,userId); }
function checkCsrf(session,f){ return Boolean(session?.csrf && f?.csrf && session.csrf===f.csrf); }
function checkJson(v){ if(!String(v||'').trim()) return true; try { JSON.parse(v); return true; } catch { return false; } }
function ipOf(req){ return String(req.headers.get('x-nf-client-connection-ip') || req.headers.get('x-forwarded-for') || '').split(',')[0].trim(); }
function loginBlocked(state,ip,email){ const cutoff=unixNow()-15*60; state.loginAttempts=(state.loginAttempts||[]).filter(x=>Number(x.failedAt)>unixNow()-86400); return state.loginAttempts.filter(x=>x.ip===ip&&x.email===email&&Number(x.failedAt)>cutoff).length>=5; }
function recordLoginFail(state,ip,email){ state.loginAttempts.push({ip,email,failedAt:unixNow()}); }
function clearLoginFails(state,ip,email){ state.loginAttempts=state.loginAttempts.filter(x=>!(x.ip===ip&&x.email===email)); }
function uniqueSlug(rows,slug,lang,id){ return rows.some(x=>x.lang===lang&&x.slug===slug&&Number(x.id)!==Number(id||0)); }

function shell(title,body,lang='ar',head=''){
  const rtl=lang==='ar';
  return `<!doctype html><html lang="${lang}" dir="${rtl?'rtl':'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="icon" href="/favicon"><link rel="stylesheet" href="/assets/admin.css">${head}</head><body>${body}</body></html>`;
}

function publicHead(req,state,row,type){
  const base=siteBase(req,state); const path=`/${row.lang}/${type==='article'?'articles':'pages'}/${encodeURIComponent(row.slug)}`;
  const title=row.seo_title||row.title; const meta=row.meta_description||row.short_description||state.settings.default_meta_description||'';
  const canonical=row.canonical_url||base+path; const ogTitle=row.og_title||title; const ogDesc=row.og_description||meta; const ogImage=row.og_image||state.settings.default_og_image||'';
  const schema=jsonSafe(row.schema_json||''); const globalSchema=jsonSafe(state.settings.global_schema||'');
  return `<meta name="description" content="${attr(meta)}"><meta name="keywords" content="${attr([row.focus_keyword,row.secondary_keywords].filter(Boolean).join(', '))}"><meta name="robots" content="${row.robots_index?'index':'noindex'},${row.robots_follow?'follow':'nofollow'}"><link rel="canonical" href="${attr(canonical)}"><meta property="og:title" content="${attr(ogTitle)}"><meta property="og:description" content="${attr(ogDesc)}">${ogImage?`<meta property="og:image" content="${attr(ogImage)}">`:''}<meta property="og:url" content="${attr(canonical)}"><meta property="og:type" content="${type==='article'?'article':'website'}">${schema?`<script type="application/ld+json">${schema}</script>`:''}${globalSchema?`<script type="application/ld+json">${globalSchema}</script>`:''}${state.settings.global_head_code||''}`;
}

function nav(lang){
  const ar=lang==='ar';
  return `<header class="topbar"><div class="container nav"><a class="brand" href="/${lang}/index.html"><img src="/assets/logo.jpg" alt="Rassmiy Marketing"><span class="brand-copy"><b>RASSMIY</b><span>MARKETING</span></span></a><nav class="menu"><a href="/${lang}/index.html">${ar?'الرئيسية':'Home'}</a><a href="/${lang}/about.html">${ar?'من أنا':'About'}</a><a href="/${lang}/services.html">${ar?'الخدمات':'Services'}</a><a href="/${lang}/portfolio.html">${ar?'الأعمال':'Portfolio'}</a><a href="/${lang}/articles">${ar?'المقالات':'Articles'}</a><a href="/${lang}/contact.html">${ar?'تواصل':'Contact'}</a></nav><div class="nav-actions"><a class="lang" href="/${ar?'en':'ar'}/index.html">${ar?'EN':'AR'}</a><a class="btn outline" href="/admin/login">${ar?'دخول الإدارة':'Admin'}</a><a class="btn primary" href="/${lang}/contact.html">${ar?'طلب استشارة →':'Book a consultation →'}</a></div></div></header>`;
}
function footer(lang,state){ const ar=lang==='ar'; return `<footer class="footer"><div class="container footer-grid"><div><div class="brand" style="color:white"><img src="/assets/logo.jpg" alt="Rassmiy Marketing"><span class="brand-copy"><b>RASSMIY</b><span>MARKETING</span></span></div><p>${ar?'تسويق متكامل يربط الاستراتيجية، الأداء، المحتوى والتجارة الإلكترونية بنتائج أعمال قابلة للقياس.':'Integrated marketing that connects strategy, performance, content and e-commerce to measurable business results.'}</p></div><div><h4>${ar?'استكشف':'Explore'}</h4><a href="/${lang}/services.html">${ar?'الخدمات':'Services'}</a><br><a href="/${lang}/articles">${ar?'المقالات':'Articles'}</a><br><a href="/${lang}/portfolio.html">${ar?'الأعمال':'Portfolio'}</a></div><div><h4>${ar?'تواصل':'Contact'}</h4><div>${esc(state.settings.contact_email||'')}</div><div>${esc(state.settings.location||'')}</div><small>© 2026 Rassmiy Marketing</small></div></div></footer>`; }

function renderArticles(req,state,lang){
  const ar=lang==='ar'; const now=nowIso();
  const rows=state.articles.filter(x=>x.lang===lang&&x.status==='published'&&(!x.published_at||x.published_at<=now)).sort((a,b)=>String(b.published_at||b.created_at).localeCompare(String(a.published_at||a.created_at)));
  const cards=rows.length?rows.map(r=>`<article class="article-card">${r.featured_image?`<img src="${attr(r.featured_image)}" alt="${attr(r.title)}" style="width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:16px">`:'<div class="thumb"></div>'}<div class="meta"><span class="tag">${esc(r.category||'Marketing')}</span><span>${esc(String(r.published_at||r.created_at).slice(0,10))}</span></div><h3>${esc(r.title)}</h3><p>${esc(r.short_description||'')}</p><a class="link" href="/${lang}/articles/${encodeURIComponent(r.slug)}">${ar?'اقرأ المقال →':'Read article →'}</a></article>`).join(''):`<p>${ar?'لا توجد مقالات منشورة بعد.':'No published articles yet.'}</p>`;
  const head=`<meta name="description" content="${attr(ar?'مقالات عملية في التسويق الرقمي، SEO، التجارة الإلكترونية والإعلانات.':'Practical articles about digital marketing, SEO, e-commerce and paid media.')}"><link rel="stylesheet" href="/assets/styles.css">`;
  return `<!doctype html><html lang="${lang}" dir="${ar?'rtl':'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${ar?'المقالات | Rassmiy Marketing':'Articles | Rassmiy Marketing'}</title><link rel="icon" href="/favicon">${head}</head><body>${nav(lang)}<section class="page-hero"><div class="container"><div class="kicker">${ar?'المقالات':'Articles'}</div><h1>${ar?'مقالات عملية في التسويق والنمو':'Practical marketing & growth articles'}</h1><p>${ar?'SEO وAEO وGEO، التجارة الإلكترونية، الإعلانات، المحتوى والتحليلات.':'SEO, AEO, GEO, e-commerce, paid media, content and analytics.'}</p></div></section><section class="section soft"><div class="container"><div class="articles">${cards}</div></div></section>${footer(lang,state)}</body></html>`;
}

function renderContent(req,state,row,type){
  const lang=row.lang||'ar', ar=lang==='ar'; const title=row.seo_title||row.title;
  const cta=type==='article'&&row.cta_title?`<section class="section soft"><div class="container"><div class="panel"><h2>${esc(row.cta_title)}</h2><p>${esc(row.cta_text||'')}</p>${row.cta_url?`<a class="btn primary" href="${attr(row.cta_url)}">${esc(row.cta_button|| (ar?'تواصل الآن':'Contact now'))}</a>`:''}</div></div></section>`:'';
  const leadForm=type==='article'?`<section class="section"><div class="container"><div class="panel"><h2>${ar?'هل تريد تطبيق هذا على مشروعك؟':'Want to apply this to your project?'}</h2><form method="post" action="/api/lead"><input type="hidden" name="source" value="article:${attr(row.slug)}"><input type="hidden" name="page_url" value="/${lang}/articles/${attr(row.slug)}"><div class="form-grid"><input class="input" name="name" required placeholder="${ar?'الاسم':'Name'}"><input class="input" name="email" type="email" placeholder="${ar?'البريد الإلكتروني':'Email'}"><input class="input" name="phone" placeholder="${ar?'رقم الهاتف':'Phone'}"><input class="input" name="company" placeholder="${ar?'الشركة':'Company'}"></div><textarea class="input" name="message" placeholder="${ar?'اكتب هدفك أو التحدي':'Tell me your goal or challenge'}" style="margin-top:14px"></textarea><button class="btn primary" style="margin-top:14px" type="submit">${ar?'إرسال الطلب →':'Send request →'}</button></form></div></div></section>`:'';
  return `<!doctype html><html lang="${lang}" dir="${ar?'rtl':'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link rel="stylesheet" href="/assets/styles.css"><link rel="stylesheet" href="/assets/cms-public.css"><link rel="icon" href="/favicon">${publicHead(req,state,row,type)}</head><body>${nav(lang)}<section class="page-hero"><div class="container"><div class="kicker">${esc(type==='article'?(row.category|| (ar?'مقال':'Article')):(ar?'صفحة':'Page'))}</div><h1>${esc(row.title)}</h1>${row.short_description?`<p>${esc(row.short_description)}</p>`:''}</div></section><section class="section"><div class="container cms-content">${row.content||''}</div></section>${cta}${leadForm}${footer(lang,state)}</body></html>`;
}

function installPage(session,error=''){
  return shell('Install Rassmiy CMS',`<div class="auth-body"><div class="auth-card"><img class="auth-logo" src="/assets/logo.jpg" alt="Rassmiy"><h1>تهيئة Rassmiy CMS</h1><p>أنشئ حساب مدير واحد للموقع. يتم حفظ كلمة المرور كـ Scrypt hash وليس كنص مكشوف.</p>${error?`<div class="flash error">${esc(error)}</div>`:''}<form method="post" action="/install">${csrfInput(session)}<label>البريد الإلكتروني</label><input name="email" type="email" required><label>كلمة المرور</label><input name="password" type="password" required minlength="10"><label>تأكيد كلمة المرور</label><input name="confirm_password" type="password" required minlength="10"><button class="primary-btn" type="submit">إنشاء المدير</button></form></div></div>`,'ar');
}
function loginPage(session,error='',installedFlag=false){ return shell('تسجيل الدخول | Rassmiy CMS',`<div class="auth-body"><div class="auth-card"><img class="auth-logo" src="/assets/logo.jpg" alt="Rassmiy"><h1>لوحة الإدارة</h1><p>إدارة الصفحات والمقالات وSEO والعملاء المحتملين.</p>${installedFlag?'<div class="flash success">تم إنشاء النظام. سجل الدخول الآن.</div>':''}${error?`<div class="flash error">${esc(error)}</div>`:''}<form method="post" action="/admin/login">${csrfInput(session)}<label>البريد الإلكتروني</label><input name="email" type="email" required autocomplete="email"><label>كلمة المرور</label><input name="password" type="password" required autocomplete="current-password"><button class="primary-btn" type="submit">دخول</button></form><a class="back-link" href="/ar/index.html">← العودة للموقع</a></div></div>`,'ar'); }

function adminLayout(state,session,url,section,content){
  const navItems=[['dashboard','الرئيسية'],['pages','الصفحات'],['articles','المقالات'],['leads','Leads'],['settings','SEO العام'],['robots','robots.txt'],['security','الأمان']];
  return shell('Rassmiy CMS',`<div class="admin-shell"><aside class="sidebar"><a class="admin-brand" href="/admin"><img src="/assets/logo.jpg" alt="Rassmiy"><div><b>RASSMIY</b><span>CMS</span></div></a><nav>${navItems.map(([k,l])=>`<a class="${section===k?'active':''}" href="/admin?section=${k}">${l}</a>`).join('')}</nav><form method="post" action="/admin/logout">${csrfInput(session)}<button class="logout-btn" type="submit">تسجيل الخروج</button></form></aside><main class="admin-main">${flashHtml(url)}${content}</main></div>`,'ar','<meta name="robots" content="noindex,nofollow">');
}

function field(label,name,value='',type='text',extra=''){ return `<label>${label}</label><input name="${name}" type="${type}" value="${attr(value)}" ${extra}>`; }
function textarea(label,name,value='',rows=5){ return `<label>${label}</label><textarea name="${name}" rows="${rows}">${esc(value)}</textarea>`; }

function pageForm(session,row={}){ return `<form class="admin-form" method="post" action="/admin/action">${csrfInput(session)}<input type="hidden" name="action" value="save_page"><input type="hidden" name="id" value="${attr(row.id||'')}"><h2>${row.id?'تعديل الصفحة':'صفحة جديدة'}</h2><div class="form-grid">${field('العنوان','title',row.title||'','text','required')}${field('Slug','slug',row.slug||'')}${field('اللغة','lang',row.lang||'ar')}</div>${textarea('Short description','short_description',row.short_description||'',3)}${textarea('المحتوى HTML','content',row.content||'',12)}<div class="form-grid">${field('SEO Title','seo_title',row.seo_title||'')}${field('Focus keyword','focus_keyword',row.focus_keyword||'')}${field('Secondary keywords','secondary_keywords',row.secondary_keywords||'')}${field('Canonical URL','canonical_url',row.canonical_url||'')}</div>${textarea('Meta description','meta_description',row.meta_description||'',3)}<div class="form-grid">${field('OG title','og_title',row.og_title||'')}${field('OG image','og_image',row.og_image||'')}${field('Schema type','schema_type',row.schema_type||'WebPage')}</div>${textarea('OG description','og_description',row.og_description||'',3)}${textarea('Schema JSON-LD','schema_json',row.schema_json||'',6)}<div class="form-grid"><label>الحالة<select name="status"><option value="draft" ${selected(row.status||'draft','draft')}>Draft</option><option value="published" ${selected(row.status,'published')}>Published</option></select></label><label><input type="checkbox" name="robots_index" value="1" ${checked(row.robots_index!==false)}> index</label><label><input type="checkbox" name="robots_follow" value="1" ${checked(row.robots_follow!==false)}> follow</label></div><button class="primary-btn" type="submit">حفظ الصفحة</button></form>`; }
function articleForm(session,row={}){ return `<form class="admin-form" method="post" action="/admin/action">${csrfInput(session)}<input type="hidden" name="action" value="save_article"><input type="hidden" name="id" value="${attr(row.id||'')}"><h2>${row.id?'تعديل المقال':'مقال جديد'}</h2><div class="form-grid">${field('العنوان','title',row.title||'','text','required')}${field('Slug','slug',row.slug||'')}${field('اللغة','lang',row.lang||'ar')}</div>${textarea('Short description','short_description',row.short_description||'',3)}${textarea('المحتوى HTML','content',row.content||'',14)}<div class="form-grid">${field('Featured image','featured_image',row.featured_image||'')}${field('Author','author',row.author||'Mohamed Ali Rassmiy')}${field('Category','category',row.category||'')}${field('Tags','tags',row.tags||'')}</div><div class="form-grid">${field('Published at','published_at',row.published_at?String(row.published_at).slice(0,16):'','datetime-local')}${field('SEO Title','seo_title',row.seo_title||'')}${field('Focus keyword','focus_keyword',row.focus_keyword||'')}${field('Secondary keywords','secondary_keywords',row.secondary_keywords||'')}</div>${textarea('Meta description','meta_description',row.meta_description||'',3)}<div class="form-grid">${field('Canonical URL','canonical_url',row.canonical_url||'')}${field('OG title','og_title',row.og_title||'')}${field('OG image','og_image',row.og_image||'')}${field('Schema type','schema_type',row.schema_type||'Article')}</div>${textarea('OG description','og_description',row.og_description||'',3)}${textarea('Schema JSON-LD','schema_json',row.schema_json||'',6)}<h3>CTA</h3><div class="form-grid">${field('CTA title','cta_title',row.cta_title||'')}${field('CTA button','cta_button',row.cta_button||'')}${field('CTA URL','cta_url',row.cta_url||'')}</div>${textarea('CTA text','cta_text',row.cta_text||'',3)}<div class="form-grid"><label>الحالة<select name="status"><option value="draft" ${selected(row.status||'draft','draft')}>Draft</option><option value="published" ${selected(row.status,'published')}>Published</option></select></label><label><input type="checkbox" name="robots_index" value="1" ${checked(row.robots_index!==false)}> index</label><label><input type="checkbox" name="robots_follow" value="1" ${checked(row.robots_follow!==false)}> follow</label></div><button class="primary-btn" type="submit">حفظ المقال</button></form>`; }

function adminContent(state,session,url){
  const section=url.searchParams.get('section')||'dashboard';
  if(section==='dashboard'){
    const publishedPages=state.pages.filter(x=>x.status==='published').length, publishedArticles=state.articles.filter(x=>x.status==='published').length, newLeads=state.leads.filter(x=>x.status==='new').length;
    return [section,`<div class="admin-head"><div><h1>لوحة التحكم</h1><p>إدارة المحتوى، SEO وLeads.</p></div><a class="primary-btn" href="/ar/index.html">عرض الموقع</a></div><div class="stats"><div class="stat"><b>${state.pages.length}</b><span>Pages</span></div><div class="stat"><b>${publishedPages}</b><span>Published Pages</span></div><div class="stat"><b>${state.articles.length}</b><span>Articles</span></div><div class="stat"><b>${publishedArticles}</b><span>Published Articles</span></div><div class="stat"><b>${state.leads.length}</b><span>Leads</span></div><div class="stat"><b>${newLeads}</b><span>New Leads</span></div></div>`];
  }
  if(section==='pages'){
    const edit=Number(url.searchParams.get('edit')||0); const row=edit?state.pages.find(x=>Number(x.id)===edit):{};
    const rows=state.pages.map(r=>`<tr><td>${esc(r.title)}</td><td>${esc(r.lang)}</td><td>/${esc(r.slug)}</td><td>${esc(r.status)}</td><td><a href="/admin?section=pages&edit=${r.id}">تعديل</a> · <a target="_blank" href="/${r.lang}/pages/${encodeURIComponent(r.slug)}">عرض</a></td></tr>`).join('');
    return [section,`<div class="admin-head"><div><h1>الصفحات</h1><p>SEO مستقل لكل صفحة.</p></div></div>${pageForm(session,row||{})}<div class="admin-table-wrap"><table><thead><tr><th>العنوان</th><th>Lang</th><th>Slug</th><th>Status</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="5">لا توجد صفحات بعد.</td></tr>'}</tbody></table></div>`];
  }
  if(section==='articles'){
    const edit=Number(url.searchParams.get('edit')||0); const row=edit?state.articles.find(x=>Number(x.id)===edit):{};
    const rows=state.articles.map(r=>`<tr><td>${esc(r.title)}</td><td>${esc(r.lang)}</td><td>/${esc(r.slug)}</td><td>${esc(r.status)}</td><td><a href="/admin?section=articles&edit=${r.id}">تعديل</a> · <a target="_blank" href="/${r.lang}/articles/${encodeURIComponent(r.slug)}">عرض</a></td></tr>`).join('');
    return [section,`<div class="admin-head"><div><h1>المقالات</h1><p>CMS مقالات كامل مع SEO وCTA وLead source.</p></div></div>${articleForm(session,row||{})}<div class="admin-table-wrap"><table><thead><tr><th>العنوان</th><th>Lang</th><th>Slug</th><th>Status</th><th></th></tr></thead><tbody>${rows||'<tr><td colspan="5">لا توجد مقالات بعد.</td></tr>'}</tbody></table></div>`];
  }
  if(section==='leads'){
    const rows=[...state.leads].sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))).map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.email)}</td><td>${esc(r.phone)}</td><td>${esc(r.company)}</td><td>${esc(r.source)}</td><td>${esc(r.created_at.slice(0,16).replace('T',' '))}</td><td><form method="post" action="/admin/action">${csrfInput(session)}<input type="hidden" name="action" value="lead_status"><input type="hidden" name="id" value="${r.id}"><select name="status" onchange="this.form.submit()"><option ${selected(r.status,'new')}>new</option><option ${selected(r.status,'contacted')}>contacted</option><option ${selected(r.status,'qualified')}>qualified</option><option ${selected(r.status,'closed')}>closed</option></select></form></td></tr>`).join('');
    return [section,`<div class="admin-head"><div><h1>Leads</h1><p>الطلبات الواردة من صفحات الموقع والمقالات.</p></div></div><div class="admin-table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Company</th><th>Source</th><th>Date</th><th>Status</th></tr></thead><tbody>${rows||'<tr><td colspan="7">لا توجد Leads بعد.</td></tr>'}</tbody></table></div>`];
  }
  if(section==='settings'){
    const s=state.settings;
    return [section,`<div class="admin-head"><div><h1>SEO & Site Settings</h1><p>هذه إعدادات عامة للموقع، منفصلة عن SEO لكل صفحة ومقال.</p></div></div><form class="admin-form" method="post" action="/admin/action">${csrfInput(session)}<input type="hidden" name="action" value="save_settings"><div class="form-grid">${field('Site name','site_name',s.site_name)}${field('Site URL','site_url',s.site_url)}${field('Contact email','contact_email',s.contact_email,'email')}${field('Location','location',s.location)}</div>${textarea('Default meta description','default_meta_description',s.default_meta_description,3)}${textarea('Site keywords','site_keywords',s.site_keywords,3)}<div class="form-grid">${field('Favicon path / URL','favicon_path',s.favicon_path)}${field('Default OG image','default_og_image',s.default_og_image)}${field('GA4 ID','ga4_id',s.ga4_id)}${field('GTM ID','gtm_id',s.gtm_id)}</div>${textarea('Global Schema JSON-LD','global_schema',s.global_schema,7)}${textarea('Global HEAD code','global_head_code',s.global_head_code,6)}<button class="primary-btn" type="submit">حفظ الإعدادات</button></form>`];
  }
  if(section==='robots') return [section,`<div class="admin-head"><div><h1>robots.txt</h1><p>تحكم مباشر في ملف robots.</p></div></div><form class="admin-form" method="post" action="/admin/action">${csrfInput(session)}<input type="hidden" name="action" value="save_robots">${textarea('robots.txt','robots_txt',state.settings.robots_txt,16)}<button class="primary-btn" type="submit">حفظ robots.txt</button></form>`];
  if(section==='security') return [section,`<div class="admin-head"><div><h1>الأمان</h1><p>تغيير كلمة مرور المدير.</p></div></div><form class="admin-form" method="post" action="/admin/action">${csrfInput(session)}<input type="hidden" name="action" value="change_password">${field('كلمة المرور الحالية','current_password','','password','required')}${field('كلمة المرور الجديدة','new_password','','password','required minlength="10"')}<button class="primary-btn" type="submit">تغيير كلمة المرور</button></form>`];
  return ['dashboard',''];
}

async function handleAdminAction(req,state,session){
  const f=formToObject(await req.formData()); if(!checkCsrf(session,f)) return html('Invalid CSRF token',419);
  const action=f.action||'';
  try {
    if(action==='save_page'){
      const id=Number(f.id||0), title=String(f.title||'').trim(), lang=f.lang==='en'?'en':'ar', slug=String(f.slug||'').trim()||slugify(title); if(!title||!slug) throw new Error('أدخل عنوانًا وSlug صحيحًا.'); if(uniqueSlug(state.pages,slug,lang,id)) throw new Error('الـSlug مستخدم بالفعل لنفس اللغة.'); if(!checkJson(f.schema_json)) throw new Error('Schema JSON-LD غير صالح.');
      const existing=id?state.pages.find(x=>Number(x.id)===id):null; const row={...(existing||{}),id:existing?.id||++state.counters.page,lang,title,slug,short_description:f.short_description||'',content:f.content||'',status:f.status==='published'?'published':'draft',seo_title:f.seo_title||'',meta_description:f.meta_description||'',focus_keyword:f.focus_keyword||'',secondary_keywords:f.secondary_keywords||'',canonical_url:f.canonical_url||'',robots_index:Boolean(f.robots_index),robots_follow:Boolean(f.robots_follow),og_title:f.og_title||'',og_description:f.og_description||'',og_image:f.og_image||'',schema_type:f.schema_type||'WebPage',schema_json:f.schema_json||'',created_at:existing?.created_at||nowIso(),updated_at:nowIso()};
      if(existing) Object.assign(existing,row); else state.pages.push(row); await saveState(state); return redirect(flashUrl('/admin?section=pages','تم حفظ الصفحة بنجاح.'));
    }
    if(action==='save_article'){
      const id=Number(f.id||0), title=String(f.title||'').trim(), lang=f.lang==='en'?'en':'ar', slug=String(f.slug||'').trim()||slugify(title); if(!title||!slug) throw new Error('أدخل عنوانًا وSlug صحيحًا.'); if(uniqueSlug(state.articles,slug,lang,id)) throw new Error('الـSlug مستخدم بالفعل لنفس اللغة.'); if(!checkJson(f.schema_json)) throw new Error('Schema JSON-LD غير صالح.');
      const existing=id?state.articles.find(x=>Number(x.id)===id):null; const row={...(existing||{}),id:existing?.id||++state.counters.article,lang,title,slug,short_description:f.short_description||'',content:f.content||'',featured_image:f.featured_image||'',author:f.author||'Mohamed Ali Rassmiy',status:f.status==='published'?'published':'draft',published_at:f.published_at?new Date(f.published_at).toISOString():'',category:f.category||'',tags:f.tags||'',cta_title:f.cta_title||'',cta_text:f.cta_text||'',cta_button:f.cta_button||'',cta_url:f.cta_url||'',seo_title:f.seo_title||'',meta_description:f.meta_description||'',focus_keyword:f.focus_keyword||'',secondary_keywords:f.secondary_keywords||'',canonical_url:f.canonical_url||'',robots_index:Boolean(f.robots_index),robots_follow:Boolean(f.robots_follow),og_title:f.og_title||'',og_description:f.og_description||'',og_image:f.og_image||'',schema_type:f.schema_type||'Article',schema_json:f.schema_json||'',created_at:existing?.created_at||nowIso(),updated_at:nowIso()};
      if(existing) Object.assign(existing,row); else state.articles.push(row); await saveState(state); return redirect(flashUrl('/admin?section=articles','تم حفظ المقال بنجاح.'));
    }
    if(action==='save_settings'){ if(!checkJson(f.global_schema)) throw new Error('Global JSON-LD غير صالح.'); for(const k of ['site_name','site_url','default_meta_description','site_keywords','contact_email','location','favicon_path','default_og_image','global_schema','global_head_code','ga4_id','gtm_id']) state.settings[k]=f[k]||''; await saveState(state); return redirect(flashUrl('/admin?section=settings','تم حفظ الإعدادات العامة.')); }
    if(action==='save_robots'){ state.settings.robots_txt=f.robots_txt||''; await saveState(state); return redirect(flashUrl('/admin?section=robots','تم تحديث robots.txt.')); }
    if(action==='lead_status'){ const lead=state.leads.find(x=>Number(x.id)===Number(f.id)); if(lead&&['new','contacted','qualified','closed'].includes(f.status)) lead.status=f.status; await saveState(state); return redirect('/admin?section=leads'); }
    if(action==='change_password'){ const u=state.users.find(x=>Number(x.id)===Number(session.userId)); if(!u||!verifyPassword(f.current_password||'',u.password_hash)||String(f.new_password||'').length<10) throw new Error('تعذر تغيير كلمة المرور. تحقق من الحالية واستخدم 10 أحرف على الأقل.'); u.password_hash=hashPassword(f.new_password); await saveState(state); return redirect(flashUrl('/admin?section=security','تم تغيير كلمة المرور.')); }
    return redirect('/admin');
  } catch(e) {
    const sec=action.includes('article')?'articles':action.includes('page')?'pages':action.includes('setting')?'settings':action.includes('robot')?'robots':action.includes('password')?'security':'dashboard';
    return redirect(flashUrl(`/admin?section=${sec}`,String(e.message||'تعذر تنفيذ العملية.'),'error'));
  }
}

export default async (req) => {
  const url=new URL(req.url), path=url.pathname; const state=await loadState(); let session=getOrCreateSession(req,state); let sessionWasChanged=true;
  const saveAnd = async (response, cookieOverride=null) => { await saveState(state); const headers=new Headers(response.headers); if(cookieOverride) headers.append('Set-Cookie',cookieOverride); else if(sessionWasChanged) headers.append('Set-Cookie',cookie('rassmiy_sid',session.sid,req)); return new Response(response.body,{status:response.status,headers}); };

  if(path==='/install'){
    if(state.users.length) return saveAnd(redirect('/admin/login'));
    if(req.method==='GET') return saveAnd(html(installPage(session)));
    if(req.method==='POST'){
      const f=formToObject(await req.formData()); if(!checkCsrf(session,f)) return saveAnd(html('Invalid CSRF token',419)); const email=String(f.email||'').trim().toLowerCase(); const pw=String(f.password||'');
      if(!/^\S+@\S+\.\S+$/.test(email)||pw.length<10||pw!==String(f.confirm_password||'')) return saveAnd(html(installPage(session,'تحقق من البريد، وطابق كلمة المرور واستخدم 10 أحرف على الأقل.'),400));
      const user={id:++state.counters.user,email,password_hash:hashPassword(pw),created_at:nowIso()}; state.users.push(user); await saveState(state); return saveAnd(redirect('/admin/login?installed=1'));
    }
  }

  if(path==='/admin/login'){
    if(!state.users.length) return saveAnd(redirect('/install'));
    if(isAdmin(session)) return saveAnd(redirect('/admin'));
    if(req.method==='GET') return saveAnd(html(loginPage(session,'',url.searchParams.get('installed')==='1')));
    if(req.method==='POST'){
      const f=formToObject(await req.formData()); if(!checkCsrf(session,f)) return saveAnd(html('Invalid CSRF token',419)); const email=String(f.email||'').trim().toLowerCase(), ip=ipOf(req);
      if(loginBlocked(state,ip,email)){ await saveState(state); return saveAnd(html(loginPage(session,'محاولات كثيرة. حاول بعد 15 دقيقة.'),429)); }
      const user=state.users.find(x=>x.email===email); if(!user||!verifyPassword(f.password||'',user.password_hash)){ recordLoginFail(state,ip,email); await saveState(state); return saveAnd(html(loginPage(session,'بيانات الدخول غير صحيحة.'),401)); }
      clearLoginFails(state,ip,email); session=rotateSession(state,session,user.id); await saveState(state); return saveAnd(redirect('/admin'),cookie('rassmiy_sid',session.sid,req));
    }
  }

  if(path==='/admin/logout' && req.method==='POST'){
    const f=formToObject(await req.formData()); if(checkCsrf(session,f)&&session?.sid) delete state.sessions[session.sid]; await saveState(state); return saveAnd(redirect('/admin/login'),cookie('rassmiy_sid','',req,0));
  }

  if(path==='/admin/action' && req.method==='POST'){
    if(!isAdmin(session)) return saveAnd(redirect('/admin/login'));
    const response=await handleAdminAction(req,state,session); sessionWasChanged=false; return response;
  }

  if(path==='/admin'){
    if(!isAdmin(session)) return saveAnd(redirect('/admin/login'));
    const [section,content]=adminContent(state,session,url); return saveAnd(html(adminLayout(state,session,url,section,content)));
  }

  if(path==='/api/lead' && req.method==='POST'){
    const f=formToObject(await req.formData()); const name=String(f.name||'').trim(); if(!name) return saveAnd(text('Name is required',400));
    state.leads.push({id:++state.counters.lead,name,email:f.email||'',phone:f.phone||'',company:f.company||'',message:f.message||'',source:f.source||'website',page_url:f.page_url||'',status:'new',created_at:nowIso()}); await saveState(state);
    const lang=String(f.page_url||'').startsWith('/en/')?'en':'ar'; return saveAnd(redirect(`/${lang}/contact.html?sent=1`));
  }

  if(path==='/robots.txt'){
    let body=state.settings.robots_txt||DEFAULT_SETTINGS.robots_txt; body=body.replace(/^Sitemap:.*$/gmi,`Sitemap: ${siteBase(req,state)}/sitemap.xml`); return saveAnd(text(body));
  }
  if(path==='/sitemap.xml'){
    const base=siteBase(req,state), urls=[]; for(const lang of ['ar','en']){ for(const p of ['index.html','about.html','services.html','portfolio.html','contact.html']) urls.push(`${base}/${lang}/${p}`); urls.push(`${base}/${lang}/articles`); }
    for(const r of state.pages.filter(x=>x.status==='published')) urls.push(`${base}/${r.lang}/pages/${encodeURIComponent(r.slug)}`);
    const now=nowIso(); for(const r of state.articles.filter(x=>x.status==='published'&&(!x.published_at||x.published_at<=now))) urls.push(`${base}/${r.lang}/articles/${encodeURIComponent(r.slug)}`);
    const xml=`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${[...new Set(urls)].map(u=>`<url><loc>${esc(u)}</loc></url>`).join('\n')}\n</urlset>`; return saveAnd(text(xml,200,'application/xml; charset=utf-8'));
  }
  if(path==='/favicon') return saveAnd(redirect(state.settings.favicon_path||'/assets/logo.jpg',302));

  const articlesMatch=path.match(/^\/(ar|en)\/articles(?:\/([^/]+))?$/); if(articlesMatch){ const lang=articlesMatch[1], slug=articlesMatch[2]; if(!slug) return saveAnd(html(renderArticles(req,state,lang))); const row=state.articles.find(x=>x.lang===lang&&x.slug===decodeURIComponent(slug)&&x.status==='published'&&(!x.published_at||x.published_at<=nowIso())); return row?saveAnd(html(renderContent(req,state,row,'article'))):saveAnd(text('Not found',404)); }
  const pagesMatch=path.match(/^\/(ar|en)\/pages\/([^/]+)$/); if(pagesMatch){ const row=state.pages.find(x=>x.lang===pagesMatch[1]&&x.slug===decodeURIComponent(pagesMatch[2])&&x.status==='published'); return row?saveAnd(html(renderContent(req,state,row,'page'))):saveAnd(text('Not found',404)); }

  return saveAnd(text('Not found',404));
};

export const config = {
  path: [
    '/install', '/admin', '/admin/*', '/api/lead', '/robots.txt', '/sitemap.xml', '/favicon',
    '/ar/articles', '/ar/articles/*', '/en/articles', '/en/articles/*', '/ar/pages/*', '/en/pages/*'
  ]
};
