RASSMIY MARKETING — BILINGUAL UI/UX PROTOTYPE

Open:
- en/index.html for English
- ar/index.html for Arabic

Included:
Home, About, Services, Portfolio, Articles, Article Detail, Contact, Login, Client Dashboard.
Arabic uses RTL; English uses LTR.
SEO starter files: robots.txt, sitemap.xml, hreflang links.
The login/dashboard are front-end UI prototypes only; no authentication/backend is included.
