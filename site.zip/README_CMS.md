# Rassmiy Marketing CMS — Production Upgrade

This package upgrades the original bilingual static prototype into a real multi-page CMS with a Node.js backend and SQLite database. It uses **no third-party npm packages**.

## Requirements
- Node.js 22.5+ (Node 24+ recommended)
- A writable `data/` directory

## Run locally
```bash
npm start
```
Open `http://localhost:3000/install` once, create the admin account, then use `/admin`.

## Production
Set `PORT` if your platform requires it. Persist the `data/` directory/volume so content and accounts survive deployments. Put the app behind HTTPS in production.

## Security
- Real server-side authentication
- Passwords stored using scrypt + random salt, never plaintext
- HttpOnly / SameSite session cookies; Secure is added automatically on HTTPS
- CSRF tokens on state-changing forms
- Login rate limiting
- Admin pages are `noindex,nofollow`
- Server does not expose the SQLite database or application source as static files

## CMS features
- Multi-page CRUD: AR/EN, title, slug, short description, HTML content, status, navigation metadata
- Full article/blog system: category, tags, publish date, featured image, author, content
- Separate site-wide SEO defaults from per-page/per-article SEO
- SEO: title, meta description, focus keyword, secondary keywords, canonical, robots index/follow, Open Graph, JSON-LD schema
- Editable global schema and head code
- GA4 and Google Tag Manager fields
- Editable favicon path or URL; existing static pages point to the dynamic favicon endpoint
- Editable `robots.txt`
- Automatic `sitemap.xml` containing static pages plus all published CMS content
- Lead-driven article CTA and lead inbox with source tracking/status
- Password change panel

## Routes
- `/admin` — CMS dashboard
- `/install` — one-time installation (auto-disabled after an admin exists)
- `/ar/articles`, `/en/articles` — dynamic blog indexes
- `/ar/articles/{slug}`, `/en/articles/{slug}` — article pages
- `/ar/pages/{slug}`, `/en/pages/{slug}` — CMS pages
- `/robots.txt`
- `/sitemap.xml`
- `/favicon`

## Existing site
The original static bilingual public pages remain intact for backward compatibility. Their article links now point to the dynamic blog and their old prototype login/dashboard links redirect to the real admin.

## Important deployment note
A real backend cannot run on pure static hosting. Deploy this package to a Node-capable host. If the current host is static-only, move the project to a Node host or serverless platform with persistent storage.
