import crypto from 'node:crypto';
import { form,body,redirect,json } from '../lib/http.mjs';
import { upsert,settings } from '../data/store.mjs';

const bucket=new Map();
function limited(req,key='public',limit=20,windowMs=60_000){const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'local').split(',')[0];const k=key+':'+ip;const now=Date.now();let v=bucket.get(k)||{n:0,t:now};if(now-v.t>windowMs)v={n:0,t:now};v.n++;bucket.set(k,v);return v.n>limit;}
function clean(v,max=1000){return String(v??'').trim().slice(0,max)}
async function saveForm(req,res,collection,status){if(limited(req,collection,12))return json(res,429,{ok:false,error:'too_many_requests'});const f=await form(req);if(f.company_website)return redirect(res,'/');const item={id:crypto.randomUUID(),...Object.fromEntries(Object.entries(f).map(([k,v])=>[k,clean(v,k==='notes'||k==='message'||k==='products_needed'?5000:500)])),status,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};upsert(collection,item);return redirect(res,`/success?type=${encodeURIComponent(collection)}`)}
export async function publicApi(req,res,url){
 if(req.method==='POST'&&url.pathname==='/api/contractors')return saveForm(req,res,'contractor_leads','New');
 if(req.method==='POST'&&url.pathname==='/api/suppliers')return saveForm(req,res,'supplier_leads','New');
 if(req.method==='POST'&&url.pathname==='/api/contact')return saveForm(req,res,'contact_messages','New');
 if(req.method==='POST'&&url.pathname==='/api/quotations')return saveForm(req,res,'quotation_requests','New');
 if(req.method==='POST'&&url.pathname==='/api/events'){if(limited(req,'events',60))return json(res,204,{});let payload={};try{payload=JSON.parse((await body(req,200_000)).toString('utf8'));}catch{}upsert('events',{id:crypto.randomUUID(),type:clean(payload.type,100),payload:payload.payload||{},path:clean(payload.path,300),created_at:new Date().toISOString()});return json(res,200,{ok:true});}
 if(req.method==='GET'&&url.pathname==='/api/health')return json(res,200,{ok:true,service:'buildflow',version:'0.1.0',time:new Date().toISOString()});
 return false;
}
