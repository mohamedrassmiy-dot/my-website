import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { send,notFound,redirect } from './src/lib/http.mjs';
import { verifySession } from './src/lib/security.mjs';
import { homepage,projectsPage,projectDetails,productsPage,productDetails,contractorsPage,suppliersPage,contactPage,quotationPage,aboutPage } from './src/pages/public.mjs';
import { publicApi } from './src/api/public.mjs';
import { adminAction } from './src/api/admin.mjs';
import { loginPage,adminRoute } from './src/pages/admin.mjs';
import { list,settings } from './src/data/store.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const publicDir=path.join(__dirname,'public');
const port=Number(process.env.PORT||3000);
const siteUrl=(process.env.SITE_URL||`http://localhost:${port}`).replace(/\/$/,'');
const mime={'.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.webp':'image/webp','.json':'application/json; charset=utf-8'};
function staticFile(pathname){
  const rel=pathname.replace(/^\/+/,''),f=path.resolve(publicDir,rel);
  if(!f.startsWith(publicDir+path.sep)||!fs.existsSync(f)||!fs.statSync(f).isFile())return null;
  return f;
}
function successPage(type){const label={contractor_leads:'تسجيل المقاول أو الفني',supplier_leads:'تسجيل المورد',contact_messages:'الرسالة',quotation_requests:'طلب عرض السعر'}[type]||'الطلب';return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/styles.css"><title>تم الاستلام | BuildFlow</title></head><body><div class="login-wrap"><div class="login-card" style="text-align:center"><img src="/assets/buildflow-logo.webp" alt="BuildFlow"><h1>تم الاستلام بنجاح</h1><p>تم استلام ${label}، وسيتم التواصل معك قريبًا.</p><a class="btn btn-primary" href="/">العودة للرئيسية</a></div></div></body></html>`}
function sitemapXml(){const urls=['/','/projects','/products','/contractors','/suppliers','/about','/contact','/request-quotation',...list('projects').map(x=>`/projects/${x.slug}`),...list('products').map(x=>`/products/${x.slug}`)];return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u=>`  <url><loc>${siteUrl}${u}</loc><lastmod>${new Date().toISOString().slice(0,10)}</lastmod></url>`).join('\n')}\n</urlset>`}
function robots(){return `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\nSitemap: ${siteUrl}/sitemap.xml\n`;}

const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,siteUrl),p=url.pathname;
    if(p.startsWith('/api/')){const handled=await publicApi(req,res,url);if(handled!==false)return;}
    if(p==='/admin/login'&&req.method==='POST'){const handled=await adminAction(req,res,url);if(handled!==false)return;}
    if((p==='/admin/action'||p==='/admin/logout')&&req.method!=='GET'||p==='/admin/logout'){const handled=await adminAction(req,res,url);if(handled!==false)return;}
    if(p==='/robots.txt'){res.writeHead(200,{'content-type':'text/plain; charset=utf-8','cache-control':'public, max-age=300'});return res.end(robots());}
    if(p==='/sitemap.xml'){res.writeHead(200,{'content-type':'application/xml; charset=utf-8','cache-control':'public, max-age=300'});return res.end(sitemapXml());}
    const file=staticFile(p);if(file){res.writeHead(200,{'content-type':mime[path.extname(file).toLowerCase()]||'application/octet-stream','cache-control':p.startsWith('/assets/')?'public, max-age=86400':'public, max-age=300'});return fs.createReadStream(file).pipe(res);}
    if(p==='/admin/login'&&req.method==='GET')return send(res,200,loginPage());
    if(p.startsWith('/admin')){const session=verifySession(req);if(!session)return redirect(res,'/admin/login');const page=adminRoute(p,url,session);return page?send(res,200,page):notFound(res);}
    if(req.method!=='GET')return notFound(res);
    if(p==='/')return send(res,200,homepage());
    if(p==='/projects')return send(res,200,projectsPage());
    if(p.startsWith('/projects/')){const page=projectDetails(decodeURIComponent(p.slice('/projects/'.length)));return page?send(res,200,page):notFound(res);}
    if(p==='/products')return send(res,200,productsPage(url));
    if(p.startsWith('/products/')){const page=productDetails(decodeURIComponent(p.slice('/products/'.length)));return page?send(res,200,page):notFound(res);}
    if(p==='/contractors')return send(res,200,contractorsPage());
    if(p==='/suppliers')return send(res,200,suppliersPage());
    if(p==='/contact')return send(res,200,contactPage());
    if(p==='/request-quotation')return send(res,200,quotationPage(url));
    if(p==='/about')return send(res,200,aboutPage());
    if(p==='/success')return send(res,200,successPage(url.searchParams.get('type')));
    return notFound(res);
  }catch(err){console.error('[BUILD_FLOW_ERROR]',err?.stack||err);res.writeHead(Number(err.statusCode||500),{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify({error:'server_error'}));}
});
server.listen(port,'0.0.0.0',()=>console.log(`BuildFlow listening on ${port} | ${siteUrl}`));
